/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
   int a[5]={1,2,3,4,5};
   int b=a[4];
   for(int i=3;i >= 0;i--){
       a[i+1]=a[i];
   }
   a[0]=b;
   int c=a[4];
    for(int i=3;i >= 0;i--){
       a[i+1]=a[i];
   }
   a[0]=c;
   
   
   
   for(int i=0;i < 5;i++){
       printf("%d\n",a[i]);
   }

    return 0;
}
