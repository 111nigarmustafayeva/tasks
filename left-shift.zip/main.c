/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int main(){
    int arr[40],n,i;
    printf("enter size of array :");
    scanf("%d",&n);
    printf("\n enter numbers of array :");
    for(int i=0;i < n;i++){
        scanf("%d",&arr[i]);
        }
    int c;
    printf("ne qeder surusduruleceyini teyin edin :");
    scanf("%d",&c);
    
    int j;
    for(j=1;j <= c;j++){
      int  ieded=arr[0];
       for( i=0;i < n-1;i++){
           arr[i]=arr[i+1];
       }
       arr[i]=ieded;
    }
    
    for(int i=0;i < n;i++){
        printf("%d",arr[i]);
    }
    return 0;
    
}